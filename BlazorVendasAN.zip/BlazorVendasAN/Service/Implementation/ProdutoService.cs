﻿using BlazorVendasAN.Data.Context;
using BlazorVendasAN.Entities;
using BlazorVendasAN.Service.Interface;
using Microsoft.EntityFrameworkCore;

namespace BlazorVendasAN.Service.Implementation
{
    public class ProdutoService : IProdutoService
    {
        private readonly SQLServerContext _context;

        public ProdutoService(SQLServerContext context)
        {
            _context = context;
        }

        public async Task AdicionarAsync(Produto Produto)
        {
            _context.produtos.Add(Produto);
            await _context.SaveChangesAsync();
        }

        public async Task AlterarAsync(Produto Produto)
        {
            _context.produtos.Update(Produto);
            await _context.SaveChangesAsync();
        }

        public async Task ExcluirAsync(int id)
        {
            var produto = await _context.produtos.FindAsync(id);
            if (produto != null)
            {
                _context.produtos.Remove(produto);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<Produto> ObterProdutoPorIdAsync(int id)
        {
            return await _context.produtos.FindAsync(id);
        }

        public async Task<IEnumerable<Produto>> ObterTodosProdutosAsync()
        {
            return await _context.produtos.ToListAsync();
        }
    }
}
