﻿using BlazorVendasAN.Data.Context;
using BlazorVendasAN.Entities;
using BlazorVendasAN.Service.Interface;
using Microsoft.EntityFrameworkCore;

namespace BlazorVendasAN.Service.Implementation
{
    public class PedidoService:IPedidoService
    {
        private readonly SQLServerContext _context;

        public PedidoService(SQLServerContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Pedido>> ObterTodosPedidosAsync()
        {
            return await _context.pedidos.ToListAsync();
        }

        public async Task RegistrarVendaAsync(Pedido Pedido)
        {
            _context.pedidos.Add(Pedido);
            await _context.SaveChangesAsync();
        }
    }
    }

