﻿using BlazorVendasAN.Data.Context;
using BlazorVendasAN.Entities;
using BlazorVendasAN.Service.Interface;
using Microsoft.EntityFrameworkCore;

namespace BlazorVendasAN.Service.Implementation
{
    public class ClienteService:IClienteService
    {
        private readonly SQLServerContext _context;

        public ClienteService(SQLServerContext context)
        {
            _context = context;
        }

        public async Task AdicionarAsync(Cliente Cliente)
        {
          _context.clientes.Add(Cliente);
            await _context.SaveChangesAsync();
        }

        public async Task AlterarAsync(Cliente Cliente)
        {
            _context.clientes.Update(Cliente);
            await _context.SaveChangesAsync();
        }

        public async Task ExcluirAsync(int id)
        {
            var cliente = await _context.clientes.FindAsync(id);
            if (cliente != null)
            {
                _context.clientes.Remove(cliente);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<Cliente> ObterPorIdAsync(int id)
        {
           return await _context.clientes.FindAsync(id);
        }

        public async Task<Cliente> ObterPorNomeAsync(string nome)
        {
            return await _context.clientes.FindAsync(nome);
        }

        public async Task<IEnumerable<Cliente>> ObterTodosAsync()
        {
            return await _context.clientes.ToListAsync();
        }
    }
}
