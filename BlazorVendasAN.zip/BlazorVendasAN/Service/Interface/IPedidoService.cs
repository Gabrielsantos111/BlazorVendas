﻿using BlazorVendasAN.Entities;

namespace BlazorVendasAN.Service.Interface
{
    public interface IPedidoService
    {
        Task RegistrarVendaAsync(Pedido Pedido);
        Task<IEnumerable<Pedido>> ObterTodosPedidosAsync();
    }
}
