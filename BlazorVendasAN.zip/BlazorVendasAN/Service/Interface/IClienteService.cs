﻿using BlazorVendasAN.Entities;

namespace BlazorVendasAN.Service.Interface
{
    public interface IClienteService
    {
        Task<Cliente> ObterPorNomeAsync(string nome);
        Task<Cliente> ObterPorIdAsync(int id);
        Task<IEnumerable<Cliente>> ObterTodosAsync();
        Task AdicionarAsync(Cliente Cliente);
        Task AlterarAsync(Cliente Cliente);
        Task ExcluirAsync(int id);

    }
}
